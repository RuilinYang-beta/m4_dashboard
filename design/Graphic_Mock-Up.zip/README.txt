MAKE SURE TO CHANGE THE LINKS UNDER THE TAG <ul> (href ="Change this" and action="change this" in login.html) TO THE LOCATION OF THIS FOLDER IN YOUR LAPTOP
