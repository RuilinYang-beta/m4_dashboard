package DAO;

import java.sql.*;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;

import nl.utwente.di.SQL.*;

public class DAOinsert {
	/**
	 * Insert actions and its id to Action table in the database
	 * @param data List of actions to be inserted
	 * @param customer Customer Id
	 */
	public static void insertAction(List<String> data, int customer) {
		Connection connection = null;
		connection = DAOgeneral.connectToDatabase(connection);
		StringBuffer execute = new StringBuffer();
		Statement s = null;
		for (String key:data) {
			execute.append("INSERT INTO actions (id, action) VALUES(" + customer + ", '" + key + "');");
		}
		try {
			s = connection.createStatement();
			s.execute(execute.toString());
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {connection.close();} catch(SQLException e) {}
		}
	}
	
	/**
	 * Insert location or address values to Location or Address table in the database
	 * @param data List of Location or Address values to be inserted in form of JSONObject
	 * @param act Target table of the insertion, String 'loc' to insert to Location else insert to Address
	 */
	public static void insertLocation(List<JSONObject> data, String act) {
		Connection connection = null;
		connection = DAOgeneral.connectToDatabase(connection);
		String[] options = Database.OPT_LOC.split(",");
		String[] addOptions = Database.OPT_ADD.split(",");
		StringBuffer execute = new StringBuffer();
		PreparedStatement s = null;
		if (act.contentEquals("loc")) {
			for (JSONObject item:data) {
				execute.append("INSERT INTO locations VALUES(");
				for (int i = 1; i <= options.length; i ++) {
					boolean done = false;
					String c = options[i-1].split(" ")[0];
					try {
						if (item.getString(c).length() == 0) {
							execute.append("null" + ",");
							done = true;
						} else {
							execute.append("'" + item.getString(c) + "'" + ",");
							done = true;
						}
					} catch (JSONException z) {
						try {
							if (!done) {
								execute.append(item.getLong(c) + ",");
								done = true;
							}
						} catch (JSONException e) {
							if (!done) {
								execute.append("null" + ",");
							}
						}
					}
				}
				execute.setLength(execute.length()-1);
				execute.append(");");
			}
		}else {
			for (JSONObject item:data) {
				if (!item.get("address").toString().equals("null")) {
					execute.append("INSERT INTO address VALUES(");
					execute.append(item.getInt("locationId") + ",");
					for (int i = 2; i <= addOptions.length; i ++) {
						String c = addOptions[i-1].split(" ")[0];
						try {
							if (item.getJSONObject("address").getString(c).length() > 0) {
								execute.append("'" + item.getJSONObject("address").getString(c) + "'" + ",");
							} else if (item.getString(c).length() > 0) {
								execute.append("'" + item.getJSONObject("address").getString(c) + "'" + ",");
							} else {
								execute.append("null" + ",");
							}
						} catch (JSONException z) {
							try {
								execute.append(item.getJSONObject("address").getInt(c) + ",");
							} catch (JSONException e) {
								execute.append("null" + ",");
							}
						}
					}
					execute.setLength(execute.length()-1);
					execute.append(");");
				}		
				if (!item.get("address").toString().equals("null")) {
					execute.append("INSERT INTO address VALUES(");
					execute.append(item.getInt("locationId") + ",");
					for (int i = 2; i <= addOptions.length; i ++) {
						String c = addOptions[i-1].split(" ")[0];
						
						try {
							if (item.getJSONObject("address").getString(c).length() > 0) {
								execute.append("'" + item.getJSONObject("address").getString(c) + "'" + ",");
							} else if (item.getString(c).length() > 0) {
								execute.append("'" + item.getJSONObject("address").getString(c) + "'" + ",");
							} else {
								execute.append("null" + ",");
							}
						} catch (JSONException z) {
							try {
								execute.append(item.getJSONObject("address").getInt(c) + ",");
							} catch (JSONException e) {
								execute.append("null" + ",");
							}
						}
					}
					execute.setLength(execute.length()-1);
					execute.append(");");
				}
			}
		}
		try {
			System.out.println("Insert into database");
			s = connection.prepareStatement(execute.toString());
			s.executeUpdate();
		} catch (SQLException e) {
			System.out.println("ERROR");
			e.printStackTrace();
		} finally {
			if (s != null) {
				try {connection.close();}catch(SQLException e){}
			}
		}
		System.out.println("finished");
	}
	
	/**
	 * Insert linestop values to the Linestops table in the database
	 * @param data List of linestop values in form of JSONObject
	 */
	public static void insertLinestops(List<JSONObject> data) {
		Connection connection = null;
		connection = DAOgeneral.connectToDatabase(connection);
		String[] options = Database.OPT_LINE.split(",");
		StringBuffer execute = new StringBuffer();
		PreparedStatement s = null;
		for(JSONObject item:data) {
			execute.append("INSERT INTO linestops VALUES(");
			for(int i = 1; i <= options.length; i ++) {
				String c = options[i-1].split(" ")[0];
				try {
					execute.append("'" + item.getString(c) + "'" + ",");
				} catch (JSONException d) {
					try {
						if (c.equals("sta") || c.equals("std")) {
							execute.append("'" + new Timestamp((long) item.get(c)) + "',");
						} else {
							execute.append(item.getInt(c) + ",");
						}
					} catch (JSONException e) {
						execute.append("null" + ",");
					} catch (ClassCastException cce) {
						execute.append("null" + ",");
					}
				}
			}
			execute.setLength(execute.length()-1);
			execute.append(");");
		}
		try {
			System.out.println("Insert into database");
			s = connection.prepareStatement(execute.toString());
			s.executeUpdate();
		} catch (SQLException e) {
			System.out.println("ERROR");
			e.printStackTrace();
		} finally {
			if (s != null) {
				try {connection.close();}catch(SQLException e){}
			}
		}
		System.out.println("finished Linestops");
	}
	
	/**
	 * Insert booking values to the Bookings table in the database
	 * @param data List of booking values in form of JSONObject
	 * @param command SQL command to be used
	 * @param opts Type of the values inside the table (INT,VARCHAR,etc.)
	 */
	public static void insertDatabase(List<JSONObject> data, String command, String opts) {
		Connection connection = null;
		connection = DAOgeneral.connectToDatabase(connection);
		String[] options = opts.split(",");
		StringBuffer execute = new StringBuffer();
		PreparedStatement s = null;
		for (JSONObject item:data) {
			execute.append(command);
			for (int i = 1; i <= options.length; i ++) {
				String c = options[i-1].split(" ")[0];
				try {
					execute.append("'" + item.getString(c) + "'" + ",");
				} catch (JSONException d) {
					try {
						if (c.equals("createdOn") || c.equals("referenceDate")) {
							execute.append("'" + new Timestamp((long) item.get(c)) + "',");
						} else {
							execute.append(item.getInt(c) + ",");
						}
					} catch (JSONException e) {
						execute.append("null" + ",");
					} catch (ClassCastException cce) {
						execute.append("null" + ",");
					}
				}
			}
			execute.setLength(execute.length()-1);
			execute.append(");");
		}
		try {
			s = connection.prepareStatement(execute.toString());
			s.executeUpdate();
		} catch (SQLException e) {
			System.out.println("ERROR");
			e.printStackTrace();
		} finally {
			if (s != null) {
				try {connection.close();}catch(SQLException e){}
			}
		}
	}
	
	/**
	 * Insert customer values to Customer table in the database
	 * @param name Name of the customer
	 * @param link Link for the customer data
	 * @return
	 */
	public static String insertCustomer(String name, String link) {
		Connection connection = null;
		connection = DAOgeneral.connectToDatabase(connection);
		PreparedStatement stm = null;
		try {
			String command = "INSERT INTO customers (name, link) VALUES (?, ?)";
			stm = connection.prepareStatement(command);
			stm.setString(1, name);
			stm.setString(2, link);
		} catch (SQLException e) {
			return "value error";
		}
		try {
			stm.executeQuery();
			try {connection.close();} catch(SQLException e) {}
			return "WORKS";
		} catch (SQLException e) {
			try {connection.close();} catch(SQLException f) {}
			return e.toString();
		}
	}
}
